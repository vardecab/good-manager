var examples = [
    "1. BEING ON TIME",
    "2. WORK ETHIC",
    "3. EFFORT",
    "4. BODY LANGUAGE",
    "5. ENERGY",
    "6. ATTITUDE",
    "7. PASSION",
    "8. BEING COACHABLE",
    "9. DOING EXTRA",
    "10. BEING PREPARED"
];

var random_text = examples[Math.floor(Math.random() * examples.length)];